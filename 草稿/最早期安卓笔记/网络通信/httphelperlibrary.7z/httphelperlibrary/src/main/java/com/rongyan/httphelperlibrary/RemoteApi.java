package com.rongyan.httphelperlibrary;

import com.rongyan.httphelperlibrary.resultEntity.EventEntity;
import com.rongyan.httphelperlibrary.resultEntity.GroupInfoEntity;
import com.rongyan.httphelperlibrary.resultEntity.GroupMemberEntity;
import com.rongyan.httphelperlibrary.resultEntity.ObjectInfoEntity;
import com.rongyan.httphelperlibrary.resultEntity.UserEntity;

import org.json.JSONObject;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;
import retrofit2.http.Url;

/**
 * Created by XRY on 2016/10/7.
 */

public interface RemoteApi {

    @FormUrlEncoded
    @POST
    Call<RemoteDataResult<UserEntity>> loginForm(@Url String url, @Field("") JSONObject jsonObject);

    @FormUrlEncoded
    @POST
    Call<RemoteDataResult> register(@Url String url, @Field("") JSONObject jsonObject);

    @FormUrlEncoded
    @POST
    Call<RemoteDataResult> editPassword(@Url String url, @Field("") JSONObject jsonObject);

    @FormUrlEncoded
    @POST
    Call<RemoteDataResult> fullUserInfo(@Url String url, @Field("") JSONObject jsonObject);

    @FormUrlEncoded
    @POST
    Call<RemoteDataResult> editUserInfo(@Url String url, @Field("") JSONObject jsonObject);

    /*****************************团队*************************/

    @FormUrlEncoded
    @POST
    Call<RemoteDataResult> createGroup(@Url String url, @Field("") JSONObject jsonObject);

    @FormUrlEncoded
    @POST
    Call<RemoteDataResult> joinGroup(@Url String url, @Field("") JSONObject jsonObject);

    @FormUrlEncoded
    @POST
    Call<RemoteDataResult<List<GroupMemberEntity>>> returnGroupMemberList(@Url String url
            , @Field("") JSONObject jsonObject);

    @FormUrlEncoded
    @POST
    <T> Call<RemoteDataResult<List<GroupInfoEntity>>> returnGroupList(@Url String url
            , @Field("") JSONObject jsonObject);

    @FormUrlEncoded
    @POST
    Call<RemoteDataResult<GroupInfoEntity>> returnGroupInfo(@Url String url
            , @Field("") JSONObject jsonObject);

    @FormUrlEncoded
    @POST
    Call<RemoteDataResult> editGroupInfo(@Url String url, @Field("") JSONObject jsonObject);

    @FormUrlEncoded
    @POST
    Call<RemoteDataResult> deleteGroup(@Url String url, @Field("") JSONObject jsonObject);

    @FormUrlEncoded
    @POST
    Call<RemoteDataResult> quitGroup(@Url String url, @Field("") JSONObject jsonObject);

    @FormUrlEncoded
    @POST
    Call<RemoteDataResult> deleteGroupMember(@Url String url, @Field("") JSONObject jsonObject);
    /*****************************团队*************************/

    /*******************************对象管理*******************/
    @FormUrlEncoded
    @POST
    Call<RemoteDataResult> createObject(@Url String url, @Field("") JSONObject jsonObject);

    @FormUrlEncoded
    @POST
    Call<RemoteDataResult> editObject(@Url String url, @Field("") JSONObject jsonObject);

    @FormUrlEncoded
    @POST
    Call<RemoteDataResult> deleteObject(@Url String url, @Field("") JSONObject jsonObject);

    @FormUrlEncoded
    @POST
    Call<RemoteDataResult<List<ObjectInfoEntity>>> returnObjectList(@Url String url
            , @Field("") JSONObject jsonObject);

    @FormUrlEncoded
    @POST
    Call<RemoteDataResult<ObjectInfoEntity>> returnObject(@Url String url
            , @Field("") JSONObject jsonObject);

    /*******************************对象管理*******************/

    /******************************事务管理***********************/
    @FormUrlEncoded
    @POST
    Call<RemoteDataResult> createEvent(@Url String url, @Field("") JSONObject jsonObject);

    @FormUrlEncoded
    @POST
    Call<RemoteDataResult> editEvent(@Url String url, @Field("") JSONObject jsonObject);

    @FormUrlEncoded
    @POST
    Call<RemoteDataResult> deleteEvent(@Url String url, @Field("") JSONObject jsonObject);

    @FormUrlEncoded
    @POST
    Call<RemoteDataResult<List<EventEntity>>> returnEventList(@Url String url
            , @Field("") JSONObject jsonObject);

    @FormUrlEncoded
    @POST
    Call<RemoteDataResult<EventEntity>> returnEvent(@Url String url
            , @Field("") JSONObject jsonObject);
}
