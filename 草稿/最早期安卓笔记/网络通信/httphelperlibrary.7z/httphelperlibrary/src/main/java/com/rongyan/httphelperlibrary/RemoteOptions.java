package com.rongyan.httphelperlibrary;

import com.rongyan.httphelperlibrary.postEntity.EditPasswordPost;
import com.rongyan.httphelperlibrary.postEntity.LoginPost;

/**
 * Created by XRY on 2016/10/7.
 */

public class RemoteOptions {
    public boolean loginCheck(LoginPost loginPost) {

        return true;
    }

    public boolean registerCheck(String username, String password, String confirmpassword, String verifacationcode) {
        if (!password.equals(confirmpassword)) {
            return false;
        }
        return true;
    }

    public EditPasswordPost editPasswordCheck(int userId, String oldPassword, String newPassword
            , String confirmNewPassword) {
        if (!newPassword.equals(confirmNewPassword)) {
            return new EditPasswordPost(userId, oldPassword, newPassword);
        }
        return null;
    }


}
