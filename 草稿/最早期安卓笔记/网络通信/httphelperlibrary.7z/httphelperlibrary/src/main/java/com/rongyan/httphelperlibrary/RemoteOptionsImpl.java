package com.rongyan.httphelperlibrary;

import android.support.annotation.Nullable;

import com.rongyan.httphelperlibrary.resultEntity.UserEntity;

import org.json.JSONException;
import org.json.JSONObject;

import retrofit2.Call;
import retrofit2.Callback;

/**
 * Created by XRY on 2016/10/7.
 */

public class RemoteOptionsImpl {
    private HttpHelper mHttpHelper = new HttpHelper();
    private RemoteOptions mRemoteOptions = new RemoteOptions();

    /**
     * 登录
     *
     * @param url
     * @param verifacationcode
     * @param baseUrl
     * @param callback
     */
    public void login(String username,String password
            , String baseUrl, String url, Callback<RemoteDataResult<UserEntity>> callback
            , @Nullable String verifacationcode){
        JSONObject jsonObject = new JSONObject();

        if (verifacationcode == null) {
            try {
                jsonObject.put("username",username);
                jsonObject.put("password",password);
            } catch (JSONException e) {
                e.printStackTrace();
            }
            RemoteApi service = mHttpHelper.getService(RemoteApi.class, baseUrl);
            Call<RemoteDataResult<UserEntity>> login = service.loginForm(url, jsonObject);
            login.enqueue(callback);
        } else {
            try {
                jsonObject.put("verifacationcode",verifacationcode);
                jsonObject.put("username",username);
                jsonObject.put("password",password);
            } catch (JSONException e) {
                e.printStackTrace();
            }

            RemoteApi service = mHttpHelper.getService(RemoteApi.class, baseUrl);
            Call<RemoteDataResult<UserEntity>> login = service.loginForm(url, jsonObject);
            login.enqueue(callback);
        }
    }

    /**
     * 注册
     *
     * @param username
     * @param password
     * @param confirmpassword
     * @param verifacationcode
     * @param url
     * @param callback
     */
    public void register(String username, String password, String confirmpassword, String verifacationcode
            , String baseUrl, String url
            , Callback<RemoteDataResult> callback) throws JSONException {
        if (mRemoteOptions.registerCheck(username, password, confirmpassword, verifacationcode)) {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("username", username);
            jsonObject.put("password", password);
            jsonObject.put("verifacationcode", verifacationcode);
            RemoteApi service = mHttpHelper.getService(RemoteApi.class, baseUrl);
            Call<RemoteDataResult> register = service.register(url, jsonObject);
            register.enqueue(callback);
        } else {

        }
    }

    /**
     * 修改密码
     *
     * @param userId
     * @param oldPassword
     * @param newPassword
     * @param confirmNewPassword
     * @param url
     * @param callback
     */
    public void editPassword(int userId, String oldPassword, String newPassword
            , String confirmNewPassword, String baseUrl, String url, Callback<RemoteDataResult> callback) throws JSONException {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("userid", userId);
        jsonObject.put("oldpassword", oldPassword);
        jsonObject.put("newpassword", newPassword);
        jsonObject.put("confirmnewpassword", confirmNewPassword);
        RemoteApi service = mHttpHelper.getService(RemoteApi.class, baseUrl);
        Call<RemoteDataResult> remoteDataResultCall = service.editPassword(url, jsonObject);
        remoteDataResultCall.enqueue(callback);
    }

    /**
     * 完善资料
     *
     * @param url
     * @param userId
     * @param data
     * @param callback
     */
    public <T> void fullUserInfo(String baseUrl, String url, int userId, T data, Callback<RemoteDataResult> callback) throws JSONException {
        RemoteApi service = mHttpHelper.getService(RemoteApi.class, baseUrl);
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("userid", userId);
        jsonObject.put("data", data);
        Call<RemoteDataResult> remoteDataResultCall = service.fullUserInfo(url, jsonObject);
        remoteDataResultCall.enqueue(callback);
    }

    /**
     * 更改个人信息
     *
     * @param url
     * @param userId
     * @param data
     * @param callback
     * @param <T>
     */
    public <T> void editUserInfo(String baseUrl,String url, int userId, T data, Callback<RemoteDataResult> callback) throws JSONException {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("userid",userId);
        jsonObject.put("data",data);
        RemoteApi service = mHttpHelper.getService(RemoteApi.class, baseUrl);
        Call<RemoteDataResult> remoteDataResultCall = service.editUserInfo(url,jsonObject);
        remoteDataResultCall.enqueue(callback);
    }

    /**
     * 创建社交团队
     *
     * @param url
     * @param groupPostEntity
     * @param callback
     * @param <T>
     */
//    public <T> void creatGroup(String baseUrl, String url, T groupPostEntity, Callback<RemoteDataResult> callback) {
//        JSONObject jsonObject = new JSONObject();
//        jsonObject.put("")
//        RemoteApi service = mHttpHelper.getService(RemoteApi.class, baseUrl);
//        Call<RemoteDataResult> remoteDataResultCall = service.createGroup(groupPostEntity);
//        remoteDataResultCall.enqueue(callback);
//    }
//
//    /**
//     * 加入社交团队
//     *
//     * @param url
//     * @param joinGroupPostEntity
//     * @param callback
//     * @param <T>
//     */
//    public <T> void joinGroup(String url, T joinGroupPostEntity, Callback<RemoteDataResult> callback) {
//        RemoteApi service = mHttpHelper.getService(RemoteApi.class, url);
//        Call<RemoteDataResult> remoteDataResultCall = service.joinGroup(joinGroupPostEntity);
//        remoteDataResultCall.enqueue(callback);
//    }
//
//    /**
//     * 获取团队成员信息
//     *
//     * @param <T>
//     * @param url
//     * @param getMemberPostEntity
//     * @param callback
//     */
//    public <T> void returnGroupMemberList(String url, T getMemberPostEntity, Callback<RemoteDataResult<List<GroupMemberEntity>>> callback) {
//        RemoteApi service = mHttpHelper.getService(RemoteApi.class, url);
//        Call<RemoteDataResult<List<GroupMemberEntity>>> remoteDataResultCall = service.returnGroupMemberList(getMemberPostEntity);
//        remoteDataResultCall.enqueue(callback);
//    }
//
//    /**
//     * 获取团队信息
//     *
//     * @param <T>
//     * @param url
//     * @param getGroupPostEntity
//     * @param callback
//     */
//    public <T> void returnGroupList(String url, T getGroupPostEntity, Callback<RemoteDataResult<List<GroupInfoEntity>>> callback) {
//        RemoteApi service = mHttpHelper.getService(RemoteApi.class, url);
//        Call<RemoteDataResult<List<GroupInfoEntity>>> remoteDataResultCall = service.returnGroupList(getGroupPostEntity);
//        remoteDataResultCall.enqueue(callback);
//    }
//
//    /**
//     * 查看团队信息
//     *
//     * @param url
//     * @param getGroupInfoPostEntity
//     * @param callback
//     * @param <T>
//     */
//    public <T> void returnGroupInfo(String url, T getGroupInfoPostEntity, Callback<RemoteDataResult<GroupInfoEntity>> callback) {
//        RemoteApi service = mHttpHelper.getService(RemoteApi.class, url);
//        Call<RemoteDataResult<GroupInfoEntity>> remoteDataResultCall = service.returnGroupInfo(getGroupInfoPostEntity);
//        remoteDataResultCall.enqueue(callback);
//    }
//
//    /**
//     * 修改团队信息
//     *
//     * @param url
//     * @param editGroupInfoPostEntity
//     * @param callback
//     * @param <T>
//     */
//    public <T> void editGroupInfo(String url, T editGroupInfoPostEntity, Callback<RemoteDataResult> callback) {
//        RemoteApi service = mHttpHelper.getService(RemoteApi.class, url);
//        Call<RemoteDataResult> remoteDataResultCall = service.editGroupInfo(editGroupInfoPostEntity);
//        remoteDataResultCall.enqueue(callback);
//    }
//
//    /**
//     * 删除团队信息
//     *
//     * @param url
//     * @param deleteGroupPostEntity
//     * @param callback
//     * @param <T>
//     */
//    public <T> void deleteGroup(String url, T deleteGroupPostEntity, Callback<RemoteDataResult> callback) {
//        RemoteApi service = mHttpHelper.getService(RemoteApi.class, url);
//        Call<RemoteDataResult> remoteDataResultCall = service.deleteGroup(deleteGroupPostEntity);
//        remoteDataResultCall.enqueue(callback);
//    }
//
//    /**
//     * 退出团队信息
//     *
//     * @param url
//     * @param quitGroupPostEntity
//     * @param callback
//     * @param <T>
//     */
//    public <T> void quitGroup(String url, T quitGroupPostEntity, Callback<RemoteDataResult> callback) {
//        RemoteApi service = mHttpHelper.getService(RemoteApi.class, url);
//        Call<RemoteDataResult> remoteDataResultCall = service.quitGroup(quitGroupPostEntity);
//        remoteDataResultCall.enqueue(callback);
//    }
//
//    /**
//     * 删除团队信息
//     *
//     * @param url
//     * @param deleteGroupPostEntity
//     * @param callback
//     * @param <T>
//     */
//    public <T> void deleteGroupMemberGroup(String url, T deleteGroupPostEntity, Callback<RemoteDataResult> callback) {
//        RemoteApi service = mHttpHelper.getService(RemoteApi.class, url);
//        Call<RemoteDataResult> remoteDataResultCall = service.deleteGroupMember(deleteGroupPostEntity);
//        remoteDataResultCall.enqueue(callback);
//    }
//
//    /**
//     * 创建对象
//     *
//     * @param url
//     * @param createObjPostEntity
//     * @param callback
//     * @param <T>
//     */
//    public <T> void createObj(String url, T createObjPostEntity, Callback<RemoteDataResult> callback) {
//        RemoteApi service = mHttpHelper.getService(RemoteApi.class, url);
//        Call<RemoteDataResult> remoteDataResultCall = service.createObject(createObjPostEntity);
//        remoteDataResultCall.enqueue(callback);
//    }
//
//    /**
//     * 编辑对象
//     *
//     * @param url
//     * @param editObjPostEntity
//     * @param callback
//     * @param <T>
//     */
//    public <T> void editObj(String url, T editObjPostEntity, Callback<RemoteDataResult> callback) {
//        RemoteApi service = mHttpHelper.getService(RemoteApi.class, url);
//        Call<RemoteDataResult> remoteDataResultCall = service.editObject(editObjPostEntity);
//        remoteDataResultCall.enqueue(callback);
//    }
//
//    /**
//     * 删除对象
//     *
//     * @param url
//     * @param deleteObjPostEntity
//     * @param callback
//     * @param <T>
//     */
//    public <T> void deleteObj(String url, T deleteObjPostEntity, Callback<RemoteDataResult> callback) {
//        RemoteApi service = mHttpHelper.getService(RemoteApi.class, url);
//        Call<RemoteDataResult> remoteDataResultCall = service.deleteObject(deleteObjPostEntity);
//        remoteDataResultCall.enqueue(callback);
//    }
//
//
//    /**
//     * 对象列表返回
//     *
//     * @param url
//     * @param returnObjListPostEntity
//     * @param callback
//     * @param <T>
//     */
//    public <T> void returnObjList(String url, T returnObjListPostEntity, Callback<RemoteDataResult<List<ObjectInfoEntity>>> callback) {
//        RemoteApi service = mHttpHelper.getService(RemoteApi.class, url);
//        Call<RemoteDataResult<List<ObjectInfoEntity>>> remoteDataResultCall = service.returnObjectList(returnObjListPostEntity);
//        remoteDataResultCall.enqueue(callback);
//    }
//
//    /**
//     * 对象信息返回
//     *
//     * @param url
//     * @param returnObjInfoPostEntity
//     * @param callback
//     * @param <T>
//     */
//    public <T> void returnObjInfo(String url, T returnObjInfoPostEntity, Callback<RemoteDataResult<ObjectInfoEntity>> callback) {
//        RemoteApi service = mHttpHelper.getService(RemoteApi.class, url);
//        Call<RemoteDataResult<ObjectInfoEntity>> remoteDataResultCall = service.returnObject(returnObjInfoPostEntity);
//        remoteDataResultCall.enqueue(callback);
//    }
//
//    /**
//     * 时间添加
//     *
//     * @param url
//     * @param createEventPostEntity
//     * @param callback
//     * @param <T>
//     */
//    public <T> void creatEvent(String url, T createEventPostEntity, Callback<RemoteDataResult> callback) {
//        RemoteApi service = mHttpHelper.getService(RemoteApi.class, url);
//        Call<RemoteDataResult> remoteDataResultCall = service.createEvent(createEventPostEntity);
//        remoteDataResultCall.enqueue(callback);
//    }
//
//    /**
//     * 编辑事件
//     *
//     * @param url
//     * @param editEventPostEntity
//     * @param callback
//     * @param <T>
//     */
//    public <T> void editEvent(String url, T editEventPostEntity, Callback<RemoteDataResult> callback) {
//        RemoteApi service = mHttpHelper.getService(RemoteApi.class, url);
//        Call<RemoteDataResult> remoteDataResultCall = service.editEvent(editEventPostEntity);
//        remoteDataResultCall.enqueue(callback);
//    }
//
//    /**
//     * 删除事件
//     *
//     * @param url
//     * @param deleteEventPostEntity
//     * @param callback
//     * @param <T>
//     */
//    public <T> void deleteEvent(String url, T deleteEventPostEntity, Callback<RemoteDataResult> callback) {
//        RemoteApi service = mHttpHelper.getService(RemoteApi.class, url);
//        Call<RemoteDataResult> remoteDataResultCall = service.deleteEvent(deleteEventPostEntity);
//        remoteDataResultCall.enqueue(callback);
//    }
//
//    /**
//     * 返回事件列表
//     *
//     * @param url
//     * @param returnEventListPostEntity
//     * @param callback
//     * @param <T>
//     */
//    public <T> void returnEventList(String url, T returnEventListPostEntity, Callback<RemoteDataResult<List<EventEntity>>> callback) {
//        RemoteApi service = mHttpHelper.getService(RemoteApi.class, url);
//        Call<RemoteDataResult<List<EventEntity>>> remoteDataResultCall = service.returnEventList(returnEventListPostEntity);
//        remoteDataResultCall.enqueue(callback);
//    }
//
//    /**
//     * 查看事件信息
//     *
//     * @param url
//     * @param returnEventInfoPostEntity
//     * @param callback
//     * @param <T>
//     */
//    public <T> void returnEventInfo(String url, T returnEventInfoPostEntity, Callback<RemoteDataResult<EventEntity>> callback) {
//        RemoteApi service = mHttpHelper.getService(RemoteApi.class, url);
//        Call<RemoteDataResult<EventEntity>> remoteDataResultCall = service.returnEvent(returnEventInfoPostEntity);
//        remoteDataResultCall.enqueue(callback);
//    }


}
