package com.rongyan.httphelperlibrary.postEntity;

/**
 * Created by XRY on 2016/10/7.
 */

public class RegisterPost {
    private String username;
    private String password;
    private String verifacationcode;

    public RegisterPost(String username, String password, String verifacationcode) {
        this.username = username;
        this.password = password;
        this.verifacationcode = verifacationcode;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getVerifacationcode() {
        return verifacationcode;
    }

    public void setVerifacationcode(String verifacationcode) {
        this.verifacationcode = verifacationcode;
    }
}
