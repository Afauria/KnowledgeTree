package com.rongyan.httphelperlibrary.resultEntity;

/**
 * Created by XRY on 2016/10/12.
 */

public class GroupInfoEntity {
}
