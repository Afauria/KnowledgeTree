package com.rongyan.httphelperlibrary.postEntity;

/**
 * Created by XRY on 2016/10/7.
 */

public class EditPasswordPost {
    private int userId;
    private String oldpassword;
    private String newpassword;

    public EditPasswordPost(int userId, String oldpassword, String newpassword) {
        this.userId = userId;
        this.oldpassword = oldpassword;
        this.newpassword = newpassword;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getOldpassword() {
        return oldpassword;
    }

    public void setOldpassword(String oldpassword) {
        this.oldpassword = oldpassword;
    }

    public String getNewpassword() {
        return newpassword;
    }

    public void setNewpassword(String newpassword) {
        this.newpassword = newpassword;
    }
}
