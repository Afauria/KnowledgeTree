package com.rongyan.httphelperlibrary;

import android.content.Context;
import android.util.Log;

import com.qiniu.android.http.ResponseInfo;
import com.qiniu.android.storage.KeyGenerator;
import com.qiniu.android.storage.Recorder;
import com.qiniu.android.storage.UpCancellationSignal;
import com.qiniu.android.storage.UpCompletionHandler;
import com.qiniu.android.storage.UpProgressHandler;
import com.qiniu.android.storage.UploadManager;
import com.qiniu.android.storage.UploadOptions;
import com.qiniu.android.storage.persistent.FileRecorder;

import org.json.JSONObject;

import java.io.File;
import java.io.IOException;

/**
 * 七牛上传工具类
 * 用时间作为文件的key
 * Created by XRY on 2016/10/7.
 */

public class QiniuUtil {
    private Context context;
    private UploadManager uploadManager;
    private volatile boolean isCancled = false;

    public QiniuUtil(Context context) {
        this.context = context;
    }

    //简单上传
    public void simpleUpload(String token, String filePath) {
        File file = new File(filePath);
        uploadManager.put(file, String.valueOf(System.currentTimeMillis()), token,
                new UpCompletionHandler() {
                    @Override
                    public void complete(String key, ResponseInfo info, JSONObject res) {
                        //主线程
                        Log.i("qiniu", key + ",\r\n " + info + ",\r\n " + res);
                    }
                }, new UploadOptions(null, null, false, new UpProgressHandler() {
                    @Override
                    public void progress(String key, double percent) {
                        //主线程
                        Log.i("qiniu", key + ": " + percent);
                    }
                }, new UpCancellationSignal() {
                    @Override
                    public boolean isCancelled() {
                        return isCancled;
                    }
                }));
    }

    private void cancle() {
        isCancled = true;
    }

    //分片上传
    public void upload(String token, String filePath) {
        File file = new File(filePath);
        //设置分片上传时的断点记录保存文件夹位置
        String dirPath = context.getFilesDir() + "/QiniuTemp";
        Recorder recorder = null;
        try {
            recorder = new FileRecorder(dirPath);
        } catch (IOException e) {
            e.printStackTrace();
        }

        //分片上传时，生成标识符，用于片记录器区分是哪个文件的上传记录
        KeyGenerator keyGen = new KeyGenerator() {
            @Override
            public String gen(String key, File file) {
                return key + ":"
                        + file.getAbsolutePath() + ":"
                        + file.lastModified();
            }
        };

        uploadManager = new UploadManager(recorder, keyGen);

        uploadManager.put(file, String.valueOf(System.currentTimeMillis()), token,
                new UpCompletionHandler() {
                    @Override
                    public void complete(String key, ResponseInfo info, JSONObject res) {
                        //主线程
                        Log.i("qiniu", key + ",\r\n " + info + ",\r\n " + res);
                    }
                }, new UploadOptions(null, null, false, new UpProgressHandler() {
                    @Override
                    public void progress(String key, double percent) {
                        //主线程
                        Log.i("qiniu", key + ": " + percent);
                    }
                }, new UpCancellationSignal() {
                    @Override
                    public boolean isCancelled() {
                        return isCancled;
                    }
                }));
    }


}
