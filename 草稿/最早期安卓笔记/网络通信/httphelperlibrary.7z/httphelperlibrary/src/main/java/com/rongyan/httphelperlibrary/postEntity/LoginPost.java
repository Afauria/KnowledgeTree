package com.rongyan.httphelperlibrary.postEntity;

import com.google.gson.annotations.SerializedName;

/**
 * Created by XRY on 2016/10/7.
 */

public class LoginPost {
    @SerializedName("username")
    private String username;
    @SerializedName("password")
    private String password;
//    private String verifactioncode;

    public LoginPost(String username, String password, String verifactioncode) {
        this.username = username;
        this.password = password;
//        this.verifactioncode = verifactioncode;
    }

    public LoginPost(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

//    public String getVerifactioncode() {
//        return verifactioncode;
//    }
//
//    public void setVerifactioncode(String verifactioncode) {
//        this.verifactioncode = verifactioncode;
//    }
}
