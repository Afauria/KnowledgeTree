package com.rongyan.httphelperlibrary;

import java.util.HashMap;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * Created by XRY on 2016/10/4.
 */

public class HttpHelper {
    private HashMap<String, Object> mServiceMap; //用于存储retrofit服务
    public HttpHelper() {
        mServiceMap = new HashMap<>();
    }

    @SuppressWarnings("unchecked")
    public <S> S getService(Class<S> serviceClass, String baseUrl) {
        /**
         * 做一个判断，如果已经存在该服务，直接取出，不存在再创建
         */
        if (mServiceMap.containsKey(serviceClass.getName())) {
            return (S) mServiceMap.get(serviceClass.getName());
        } else {
            Object obj = createService(serviceClass, baseUrl);
            mServiceMap.put(serviceClass.getName(), obj);
            return (S) obj;
        }
    }

    /**
     * 创建Retrofit服务
     * @param serviceClass
     * @param baseUrl
     * @param <S>
     * @return
     */
    private <S> S createService(Class<S> serviceClass, String baseUrl) {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(baseUrl)
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        return retrofit.create(serviceClass);
    }
}
