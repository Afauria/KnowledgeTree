package com.rongyan.httphelperlibrary;

import com.rongyan.httphelperlibrary.postEntity.EditPasswordPost;
import com.rongyan.httphelperlibrary.postEntity.LoginPost;
import com.rongyan.httphelperlibrary.postEntity.RegisterPost;
import com.rongyan.httphelperlibrary.resultEntity.EventEntity;
import com.rongyan.httphelperlibrary.resultEntity.GroupInfoEntity;
import com.rongyan.httphelperlibrary.resultEntity.GroupMemberEntity;
import com.rongyan.httphelperlibrary.resultEntity.ObjectInfoEntity;
import com.rongyan.httphelperlibrary.resultEntity.UserEntity;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

/**
 * Created by XRY on 2016/10/7.
 */

public interface RemoteApi {
    @POST
    Call<RemoteDataResult<UserEntity>> login(@Body LoginPost loginPost);

    @POST
    Call<RemoteDataResult> register(@Body RegisterPost registerPost);

    @POST
    Call<RemoteDataResult> editPassword(@Body EditPasswordPost editPasswordPost);

    @POST
    <T> Call<RemoteDataResult> fullUserInfo(@Body T data);

    @POST
    <T> Call<RemoteDataResult> editUserInfo(@Body T data);

    /*****************************团队*************************/

    @POST
    <T> Call<RemoteDataResult> createGroup(@Body T data);

    @POST
    <T> Call<RemoteDataResult> joinGroup(@Body T data);

    @POST
    <T> Call<RemoteDataResult<List<GroupMemberEntity>>> returnGroupMemberList(@Body T data);

    @POST
    <T> Call<RemoteDataResult<List<GroupInfoEntity>>> returnGroupList(@Body T data);

    @POST
    <T> Call<RemoteDataResult<GroupInfoEntity>> returnGroupInfo(@Body T data);

    @POST
    <T> Call<RemoteDataResult> editGroupInfo(@Body T data);

    @POST
    <T> Call<RemoteDataResult> deleteGroup(@Body T data);

    @POST
    <T> Call<RemoteDataResult> quitGroup(@Body T data);

    @POST
    <T> Call<RemoteDataResult> deleteGroupMember(@Body T data);
    /*****************************团队*************************/

    /*******************************对象管理*******************/

    @POST
    <T> Call<RemoteDataResult> createObject(@Body T data);

    @POST
    <T> Call<RemoteDataResult> editObject(@Body T data);

    @POST
    <T> Call<RemoteDataResult> deleteObject(@Body T data);

    @POST
    <T> Call<RemoteDataResult<List<ObjectInfoEntity>>> returnObjectList(@Body T data);

    @POST
    <T> Call<RemoteDataResult<ObjectInfoEntity>> returnObject(@Body T data);

    /*******************************对象管理*******************/

    /******************************事务管理***********************/
    @POST
    <T> Call<RemoteDataResult> createEvent(@Body T data);

    @POST
    <T> Call<RemoteDataResult> editEvent(@Body T data);

    @POST
    <T> Call<RemoteDataResult> deleteEvent(@Body T data);

    @POST
    <T> Call<RemoteDataResult<List<EventEntity>>> returnEventList(@Body T data);

    @POST
    <T> Call<RemoteDataResult<EventEntity>> returnEvent(@Body T data);






}
