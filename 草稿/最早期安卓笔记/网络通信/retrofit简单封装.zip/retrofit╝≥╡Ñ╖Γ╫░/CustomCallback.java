package com.rongyan.retrofitservice;

import java.net.SocketException;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Callback统一回调处理类
 * Created by XRY on 2016/10/21.
 */

public abstract class CustomCallback<T extends RemoteDataResult> implements Callback<T> {

    public abstract void onSuccess(Response<T> response);
    public abstract void onFail(String msg);



    @Override
    public void onResponse(Call<T> call, Response<T> response) {
        if (response.body().getResultCode() == 1) {
            onSuccess(response);
        }else if( response.body().getResultCode() == 4) {
            onFail("用户名不合法");
        }
    }

    @Override
    public void onFailure(Call<T> call, Throwable t) {
        if (t instanceof SocketException) {

        }
        onFail("fail");
    }
}
