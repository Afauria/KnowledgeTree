#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface LabRequest : NSObject<NSURLSessionDelegate>

#pragma mark-POST请求
+(NSURLSessionDataTask *)LabPOST:(UIViewController*)VC URLStr:(NSString *)URLString
                      parameters:(id)parameters
                         success:(void (^)(NSURLSessionDataTask *,NSDictionary *dict))success
                         failure:(void (^)(NSURLSessionDataTask *,NSError *error))failure;
#pragma mark-alert
+(void)alertcontroller:(NSString*)message controller:(UIViewController*)VC;

@end
