#import "LabRequest.h"

//定义一个变量
static LabRequest *manager = nil;
@implementation LabRequest

//实例化对象，懒加载
+ (instancetype)shareManager
{
    //加上互斥锁，防止多线程抢占同一资源
    @synchronized(self) {
        if (!manager) {
            manager = [[LabRequest alloc] init];
        }
        return manager;
    }
}

#pragma mark-实验室的POST封装
+(NSURLSessionDataTask *)LabPOST:(UIViewController*)VC
                          URLStr:(NSString *)URLString
                      parameters:(id)parameters
                         success:(void (^)(NSURLSessionDataTask *,NSDictionary *dict))success
                         failure:(void (^)(NSURLSessionDataTask *,NSError *error))failure
{
    [self shareManager];
    NSURLSession *session = [NSURLSession sharedSession];
    NSURL *URL= [NSURL URLWithString:URLString];
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:URL];
    request.timeoutInterval=15;
    request.HTTPMethod = @"POST";
    NSData *jsondata=[NSJSONSerialization dataWithJSONObject:parameters options:NSJSONWritingPrettyPrinted error:nil];
    NSString *jsonstr=[[NSString alloc]initWithData:jsondata encoding:NSUTF8StringEncoding];
    NSString *str=[NSString stringWithFormat:@"param=%@",jsonstr];
    NSData *data=[str dataUsingEncoding:NSUTF8StringEncoding];
    request.HTTPBody =data;
    NSURLSessionDataTask *dataTask=[session dataTaskWithRequest:request completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        if (error) {
            failure(dataTask,error);
            [self alertcontroller:@"请求失败或网络超时" controller:VC];
        }
        else{
            NSDictionary *dict= [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
            success(dataTask,dict);
            NSInteger result=[[dict objectForKey:@"resultCode"]integerValue];
            if (result == 0)
            {
                [self alertcontroller:@"未接收到参数" controller:VC];
            }
            else if (result == 2)
            {
                [self alertcontroller:@"参数错误" controller:VC];
            }
            else if (result == 201)
            {
                [self alertcontroller:@"参数格式错误" controller:VC];
            }
            else if (result == 202)
            {
                [self alertcontroller:@"缺少必须参数" controller:VC];
            }
            else if (result == 3)
            {
                [self alertcontroller:@"未查询到数据" controller:VC];
            }
            else if (result == 301)
            {
                [self alertcontroller:@"该用户不存在" controller:VC];
            }
            else if (result == 302)
            {
                [self alertcontroller:@"登录密码错误" controller:VC];
            }
            else if (result == 202)
            {
                [self alertcontroller:@"缺少必须参数" controller:VC];
            }
            else if (result == 6)
            {
                [self alertcontroller:@"对象已被禁用" controller:VC];
            }
            else if (result == 7)
            {
                [self alertcontroller:@"关键字段已被占用" controller:VC];
            }
            else if (result == 9)
            {
                [self alertcontroller:@"操作失败" controller:VC];
            }
            else if (result == 10)
            {
                [self alertcontroller:@"未登录" controller:VC];
            }
            else if (result == 11)
            {
                [self alertcontroller:@"session过期" controller:VC];
            }
            else if (result == 12)
            {
                [self alertcontroller:@"该用户被挤下线" controller:VC];
            }
            else if (result == 13)
            {
                [self alertcontroller:@"服务器响应超时" controller:VC];
            }
            else if (result == 14)
            {
                [self alertcontroller:@"服务器忙" controller:VC];
            }
            else if (result == 18)
            {
                [self alertcontroller:@"非法操作" controller:VC];
            }
            else if (result == 19)
            {
                [self alertcontroller:@"没有操作权限" controller:VC];
            }
            else if (result == 21)
            {
                [self alertcontroller:@"融云服务器异常" controller:VC];
            }
            else if (result == 22)
            {
                [self alertcontroller:@"极光服务器异常" controller:VC];
            }
            else if (result == 23)
            {
                [self alertcontroller:@"大于服务器异常" controller:VC];
            }
            else if (result == 20)
            {
                [self alertcontroller:@"短信验证码不正确" controller:VC];
            }
        }
    }];
    [dataTask resume];
    return dataTask;
}

#pragma mark NSURLSessionDataDelegate
//如果发送的请求是https的,那么才会调用该方法
//challenge 质询,挑战
//NSURLAuthenticationMethodServerTrust

-(void)URLSession:(NSURLSession *)session didReceiveChallenge:(NSURLAuthenticationChallenge *)challenge completionHandler:(void (^)(NSURLSessionAuthChallengeDisposition, NSURLCredential * _Nullable))completionHandler
{
    //如果不是服务器证书直接返回
    if(![challenge.protectionSpace.authenticationMethod isEqualToString:@"NSURLAuthenticationMethodServerTrust"])
    {
        return;
    }
    //NSURLSessionAuthChallengeDisposition 如何处理证书
    /*
     NSURLSessionAuthChallengeUseCredential = 0, 使用该证书 安装该证书
     NSURLSessionAuthChallengePerformDefaultHandling = 1, 默认采用的方式,该证书被忽略
     NSURLSessionAuthChallengeCancelAuthenticationChallenge = 2, 取消请求,证书忽略
     NSURLSessionAuthChallengeRejectProtectionSpace = 3,          拒绝
     */
    NSURLCredential *credential = [[NSURLCredential alloc]initWithTrust:challenge.protectionSpace.serverTrust];
    
    //NSURLCredential 授权信息
    completionHandler(NSURLSessionAuthChallengeUseCredential,credential);
}

#pragma mark-alert
+(void)alertcontroller:(NSString*)message controller:(UIViewController*)VC
{
    dispatch_async(dispatch_get_main_queue(), ^{
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"提示"message:message preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *defaultAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action) {}];
        [alert addAction:defaultAction];
        [VC presentViewController:alert animated:YES completion:nil];
    });
}

@end
