#import "LabInterface.h"
#import "LabRequest.h"

@implementation LabInterface

#pragma mark-登录
+(NSURLSessionDataTask *)CheckLogin:(UIViewController *)VC url:(NSString *)url username:(NSString *)username password:(NSString *)password verificationcode:(NSString *)verificationcode success:(void (^)(NSURLSessionDataTask *, id))success failure:(void (^)(NSURLSessionDataTask *, NSError *))failure{
    
    NSDictionary *paramdict=[[NSDictionary alloc]init];
    if(verificationcode==nil){
        paramdict=@{@"username":username,@"password":password};
    }else {
        paramdict=@{@"username":username,@"password":password,@"verificationcode":verificationcode};
    }
    return [LabRequest LabPOST:VC URLStr:url parameters:paramdict success:success failure:failure];
}
#pragma mark-注册
+(NSURLSessionDataTask *)RegisterUsers:(UIViewController *)VC url:(NSString *)url username:(NSString *)username password:(NSString *)password confirmpassword:(NSString *)confirmpassword verificationcode:(NSString *)verificationcode success:(void (^)(NSURLSessionDataTask *, id))success failure:(void (^)(NSURLSessionDataTask *, NSError *))failure{
    
    NSDictionary *paramdict=[[NSDictionary alloc]init];
    if(verificationcode==nil){
        paramdict=@{@"username":username,@"password":password,@"confirmpassword":confirmpassword};
    }else {
        paramdict=@{@"username":username,@"password":password,@"confirmpassword":confirmpassword,@"verificationcode":verificationcode};
    }
    return [LabRequest LabPOST:VC URLStr:url parameters:paramdict success:success failure:failure];
}
#pragma mark-修改密码
+(NSURLSessionDataTask *)EditPassword:(UIViewController *)VC url:(NSString *)url userid:(NSString *)userid oldpassword:(NSString *)oldpassword newpassword:(NSString *)newpassword confirmnewpassword:(NSString *)confirmnewpassword success:(void (^)(NSURLSessionDataTask *, id))success failure:(void (^)(NSURLSessionDataTask *, NSError *))failure{
    
    if (![newpassword isEqualToString:confirmnewpassword]){
        [LabRequest alertcontroller:@"密码输入不一致" controller:VC];
    }
    NSDictionary *paramdict=@{@"userid":userid,@"oldpassword":oldpassword,@"newpassword":newpassword,@"confirmnewpassword":confirmnewpassword};
    return [LabRequest LabPOST:VC URLStr:url parameters:paramdict success:success failure:failure];
}
#pragma mark-完善用户信息
+(NSURLSessionDataTask *)FullUserInfo:(UIViewController *)VC url:(NSString *)url userid:(NSString *)userid data:(NSDictionary *)data success:(void (^)(NSURLSessionDataTask *, id))success failure:(void (^)(NSURLSessionDataTask *, NSError *))failure{
    
    NSData *jsondata=[NSJSONSerialization dataWithJSONObject:data options:NSJSONWritingPrettyPrinted error:nil];
    NSString *jsonstr=[[NSString alloc]initWithData:jsondata encoding:NSUTF8StringEncoding];
    NSDictionary *paramdict=@{@"userid":userid,@"data":jsonstr};
    return [LabRequest LabPOST:VC URLStr:url parameters:paramdict success:success failure:failure];
}
#pragma mark-更改个人信息
+(NSURLSessionDataTask *)EditUserInfo:(UIViewController *)VC url:(NSString *)url userid:(NSString *)userid data:(NSDictionary *)data success:(void (^)(NSURLSessionDataTask *, id))success failure:(void (^)(NSURLSessionDataTask *, NSError *))failure{
    
    NSData *jsondata=[NSJSONSerialization dataWithJSONObject:data options:NSJSONWritingPrettyPrinted error:nil];
    NSString *jsonstr=[[NSString alloc]initWithData:jsondata encoding:NSUTF8StringEncoding];
    NSDictionary *paramdict=@{@"userid":userid,@"data":jsonstr};
    return [LabRequest LabPOST:VC URLStr:url parameters:paramdict success:success failure:failure];
}
#pragma mark-创建社交团队
+(NSURLSessionDataTask *)CreatGroup:(UIViewController *)VC url:(NSString *)url Data:(id)data success:(void (^)(NSURLSessionDataTask *, id))success failure:(void (^)(NSURLSessionDataTask *, NSError *))failure{
    
    NSData *datajson=[NSJSONSerialization dataWithJSONObject:data options:kNilOptions error:nil];
    NSDictionary *paramdict=@{@"Data":datajson};
    return [LabRequest LabPOST:VC URLStr:url parameters:paramdict success:success failure:failure];
}

#pragma mark-加入社交团队
+(NSURLSessionDataTask *)JoinGroup:(UIViewController *)VC url:(NSString *)url Data:(id)data success:(void (^)(NSURLSessionDataTask *, id))success failure:(void (^)(NSURLSessionDataTask *, NSError *))failure{
    
    NSData *datajson=[NSJSONSerialization dataWithJSONObject:data options:kNilOptions error:nil];
    NSDictionary *paramdict=@{@"Data":datajson};
    return [LabRequest LabPOST:VC URLStr:url parameters:paramdict success:success failure:failure];
}
#pragma mark-获取团队成员列表
+(NSURLSessionDataTask *)ReturnGroupMemberlist:(UIViewController *)VC url:(NSString *)url Data:(id)data success:(void (^)(NSURLSessionDataTask *, id))success failure:(void (^)(NSURLSessionDataTask *, NSError *))failure{
    
    NSData *datajson=[NSJSONSerialization dataWithJSONObject:data options:kNilOptions error:nil];
    NSDictionary *paramdict=@{@"Data":datajson};
    return [LabRequest LabPOST:VC URLStr:url parameters:paramdict success:success failure:failure];
}
#pragma mark-查看团队信息
+(NSURLSessionDataTask *)ReturnGroupInfo:(UIViewController *)VC url:(NSString *)url Data:(id)data success:(void (^)(NSURLSessionDataTask *, id))success failure:(void (^)(NSURLSessionDataTask *, NSError *))failure{
    
    NSData *datajson=[NSJSONSerialization dataWithJSONObject:data options:kNilOptions error:nil];
    NSDictionary *paramdict=@{@"Data":datajson};
    return [LabRequest LabPOST:VC URLStr:url parameters:paramdict success:success failure:failure];
}
#pragma mark-修改团队信息
+(NSURLSessionDataTask *)EditGroupInfo:(UIViewController *)VC url:(NSString *)url Data:(id)data success:(void (^)(NSURLSessionDataTask *, id))success failure:(void (^)(NSURLSessionDataTask *, NSError *))failure{
    
    NSData *datajson=[NSJSONSerialization dataWithJSONObject:data options:kNilOptions error:nil];
    NSDictionary *paramdict=@{@"Data":datajson};
    return [LabRequest LabPOST:VC URLStr:url parameters:paramdict success:success failure:failure];
}
#pragma mark-删除团队信息
+(NSURLSessionDataTask *)DeleteGroup:(UIViewController *)VC url:(NSString *)url Data:(id)data success:(void (^)(NSURLSessionDataTask *, id))success failure:(void (^)(NSURLSessionDataTask *, NSError *))failure{
    
    NSData *datajson=[NSJSONSerialization dataWithJSONObject:data options:kNilOptions error:nil];
    NSDictionary *paramdict=@{@"Data":datajson};
    return [LabRequest LabPOST:VC URLStr:url parameters:paramdict success:success failure:failure];
}
#pragma mark-退出社交团队
+(NSURLSessionDataTask *)QuitGroup:(UIViewController *)VC url:(NSString *)url Data:(id)data success:(void (^)(NSURLSessionDataTask *, id))success failure:(void (^)(NSURLSessionDataTask *, NSError *))failure{
    
    NSData *datajson=[NSJSONSerialization dataWithJSONObject:data options:kNilOptions error:nil];
    NSDictionary *paramdict=@{@"Data":datajson};
    return [LabRequest LabPOST:VC URLStr:url parameters:paramdict success:success failure:failure];
}
#pragma mark-删除团队成员
+(NSURLSessionDataTask *)DeleteGroupMember:(UIViewController *)VC url:(NSString *)url Data:(id)data success:(void (^)(NSURLSessionDataTask *, id))success failure:(void (^)(NSURLSessionDataTask *, NSError *))failure{
    
    NSData *datajson=[NSJSONSerialization dataWithJSONObject:data options:kNilOptions error:nil];
    NSDictionary *paramdict=@{@"Data":datajson};
    return [LabRequest LabPOST:VC URLStr:url parameters:paramdict success:success failure:failure];
}
#pragma mark-添加好友
+(NSURLSessionDataTask *)AddFriend:(UIViewController *)VC url:(NSString *)url Data:(id)data success:(void (^)(NSURLSessionDataTask *, id))success failure:(void (^)(NSURLSessionDataTask *, NSError *))failure{
    
    NSData *datajson=[NSJSONSerialization dataWithJSONObject:data options:kNilOptions error:nil];
    NSDictionary *paramdict=@{@"Data":datajson};
    return [LabRequest LabPOST:VC URLStr:url parameters:paramdict success:success failure:failure];
}
#pragma mark-删除好友
+(NSURLSessionDataTask *)DeleteFriend:(UIViewController *)VC url:(NSString *)url Data:(id)data success:(void (^)(NSURLSessionDataTask *, id))success failure:(void (^)(NSURLSessionDataTask *, NSError *))failure{
    
    NSData *datajson=[NSJSONSerialization dataWithJSONObject:data options:kNilOptions error:nil];
    NSDictionary *paramdict=@{@"Data":datajson};
    return [LabRequest LabPOST:VC URLStr:url parameters:paramdict success:success failure:failure];
}
#pragma mark-获取好友列表
+(NSURLSessionDataTask *)ReturnFriendList:(UIViewController *)VC url:(NSString *)url Data:(id)data success:(void (^)(NSURLSessionDataTask *, id))success failure:(void (^)(NSURLSessionDataTask *, NSError *))failure{
    
    NSData *datajson=[NSJSONSerialization dataWithJSONObject:data options:kNilOptions error:nil];
    NSDictionary *paramdict=@{@"Data":datajson};
    return [LabRequest LabPOST:VC URLStr:url parameters:paramdict success:success failure:failure];
}
#pragma mark-查看好友信息
+(NSURLSessionDataTask *)ReturnFriendInfo:(UIViewController *)VC url:(NSString *)url Data:(id)data success:(void (^)(NSURLSessionDataTask *, id))success failure:(void (^)(NSURLSessionDataTask *, NSError *))failure{
    
    NSData *datajson=[NSJSONSerialization dataWithJSONObject:data options:kNilOptions error:nil];
    NSDictionary *paramdict=@{@"Data":datajson};
    return [LabRequest LabPOST:VC URLStr:url parameters:paramdict success:success failure:failure];
}

@end
