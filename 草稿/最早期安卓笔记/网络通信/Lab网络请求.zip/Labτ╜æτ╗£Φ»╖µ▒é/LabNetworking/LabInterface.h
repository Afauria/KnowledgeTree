#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface LabInterface : NSObject

#pragma mark-登录
///登录
+(NSURLSessionDataTask *)CheckLogin:(UIViewController*)VC url:(NSString *)url username:(NSString*)username password:(NSString*)password verificationcode:(NSString*)verificationcode success:(void (^)(NSURLSessionDataTask *task, id responseObject))success failure:(void (^)(NSURLSessionDataTask *task, NSError *error))failure;

#pragma mark-注册
///注册
+(NSURLSessionDataTask *)RegisterUsers:(UIViewController*)VC url:(NSString *)url  username:(NSString*)username password:(NSString*)password confirmpassword:(NSString*)confirmpassword verificationcode:(NSString*)verificationcode success:(void (^)(NSURLSessionDataTask *task, id responseObject))success failure:(void (^)(NSURLSessionDataTask *task, NSError *error))failure;

#pragma mark-修改密码
///修改密码
+(NSURLSessionDataTask *)EditPassword:(UIViewController*)VC url:(NSString *)url  userid:(NSString*)userid oldpassword:(NSString*)oldpassword newpassword:(NSString*)newpassword confirmnewpassword:(NSString*)confirmnewpassword  success:(void (^)(NSURLSessionDataTask *task, id responseObject))success failure:(void (^)(NSURLSessionDataTask *task, NSError *error))failure;

#pragma mark-完善用户信息
///完善用户信息
+(NSURLSessionDataTask *)FullUserInfo:(UIViewController*)VC url:(NSString *)url  userid:(NSString*)userid data:(NSDictionary*)data  success:(void (^)(NSURLSessionDataTask *task, id responseObject))success failure:(void (^)(NSURLSessionDataTask *task, NSError *error))failure;

#pragma mark-更改个人信息
///更改个人信息
+(NSURLSessionDataTask *)EditUserInfo:(UIViewController*)VC url:(NSString *)url  userid:(NSString*)userid data:(NSDictionary*)data  success:(void (^)(NSURLSessionDataTask *task, id responseObject))success failure:(void (^)(NSURLSessionDataTask *task, NSError *error))failure;

#pragma mark-创建社交团队
///创建社交团队
+(NSURLSessionDataTask *)CreatGroup:(UIViewController*)VC url:(NSString *)url  Data:(id)data success:(void (^)(NSURLSessionDataTask *task, id responseObject))success failure:(void (^)(NSURLSessionDataTask *task, NSError *error))failure;

#pragma mark-加入社交团队
///加入社交团队
+(NSURLSessionDataTask *)JoinGroup:(UIViewController*)VC url:(NSString *)url  Data:(id)data success:(void (^)(NSURLSessionDataTask *task, id responseObject))success failure:(void (^)(NSURLSessionDataTask *task, NSError *error))failure;

#pragma mark-获取团队成员列表
///获取团队成员列表
+(NSURLSessionDataTask *)ReturnGroupMemberlist:(UIViewController*)VC url:(NSString *)url  Data:(id)data success:(void (^)(NSURLSessionDataTask *task, id responseObject))success failure:(void (^)(NSURLSessionDataTask *task, NSError *error))failure;

#pragma mark-查看团队信息
///查看团队信息
+(NSURLSessionDataTask *)ReturnGroupInfo:(UIViewController*)VC url:(NSString *)url  Data:(id)data success:(void (^)(NSURLSessionDataTask *task, id responseObject))success failure:(void (^)(NSURLSessionDataTask *task, NSError *error))failure;

#pragma mark-修改团队信息
///修改团队信息
+(NSURLSessionDataTask *)EditGroupInfo:(UIViewController*)VC url:(NSString *)url  Data:(id)data success:(void (^)(NSURLSessionDataTask *task, id responseObject))success failure:(void (^)(NSURLSessionDataTask *task, NSError *error))failure;

#pragma mark-删除团队信息
///删除团队信息
+(NSURLSessionDataTask *)DeleteGroup:(UIViewController*)VC url:(NSString *)url  Data:(id)data success:(void (^)(NSURLSessionDataTask *task, id responseObject))success failure:(void (^)(NSURLSessionDataTask *task, NSError *error))failure;

#pragma mark-退出社交团队
///退出社交团队
+(NSURLSessionDataTask *)QuitGroup:(UIViewController*)VC url:(NSString *)url  Data:(id)data success:(void (^)(NSURLSessionDataTask *task, id responseObject))success failure:(void (^)(NSURLSessionDataTask *task, NSError *error))failure;

#pragma mark-删除团队成员
///删除团队成员
+(NSURLSessionDataTask *)DeleteGroupMember:(UIViewController*)VC url:(NSString *)url  Data:(id)data success:(void (^)(NSURLSessionDataTask *task, id responseObject))success failure:(void (^)(NSURLSessionDataTask *task, NSError *error))failure;

#pragma mark-添加好友
///添加好友
+(NSURLSessionDataTask *)AddFriend:(UIViewController*)VC url:(NSString *)url  Data:(id)data success:(void (^)(NSURLSessionDataTask *task, id responseObject))success failure:(void (^)(NSURLSessionDataTask *task, NSError *error))failure;

#pragma mark-删除好友
///删除好友
+(NSURLSessionDataTask *)DeleteFriend:(UIViewController*)VC url:(NSString *)url  Data:(id)data success:(void (^)(NSURLSessionDataTask *task, id responseObject))success failure:(void (^)(NSURLSessionDataTask *task, NSError *error))failure;

#pragma mark-获取好友列表
///获取好友列表
+(NSURLSessionDataTask *)ReturnFriendList:(UIViewController*)VC url:(NSString *)url  Data:(id)data success:(void (^)(NSURLSessionDataTask *task, id responseObject))success failure:(void (^)(NSURLSessionDataTask *task, NSError *error))failure;
#pragma mark-查看好友信息
///查看好友信息
+(NSURLSessionDataTask *)ReturnFriendInfo:(UIViewController*)VC url:(NSString *)url  Data:(id)data success:(void (^)(NSURLSessionDataTask *task, id responseObject))success failure:(void (^)(NSURLSessionDataTask *task, NSError *error))failure;

@end
